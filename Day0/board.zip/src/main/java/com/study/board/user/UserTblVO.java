package com.study.board.user;

import lombok.Data;

// USER_TBL에 쿼리 전송후 나온 결과를 저장.
@Data
public class UserTblVO {
    private String userId;
    private String userPw;
    private String email;
    private String name;
    
}
