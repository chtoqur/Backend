package com.study.board.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.study.board.user.UserDAO;
import com.study.board.user.UserTblVO;

@Controller
public class MainController {

    @Autowired
    private UserDAO userdao;



    @GetMapping("/index")
    public String index()
    {
        return "index";
    }
    
    
    @GetMapping("/login")
    public String login()
    {
        return "login";
    }



    // 1. 프레임워크님 UserTblVO 객체를 생성해주세요.
    //   - new UserTblVO();
    // 2. request객체에서 post로 넘어온 "userId", "userPw"값을
    // setUserId(), setUserPw() 함수를 통해서 객체에 저장해주세요.
    // 3. 마지막으로 UserTblVO 객체의 참조값을 login()의 파라미터로 넣어주세요. 


    @PostMapping("/login")
    public String login(@ModelAttribute("UserTblVO") UserTblVO vo) throws Exception
    {
        UserTblVO resultVO = userdao.selectOneUser(vo);

        if (resultVO == null)
        {
            return "login";

        }
        else
        {
            System.out.println("id = " + resultVO.getUserId());
            System.out.println("pw = " + resultVO.getUserPw());
            System.out.println("name = " + resultVO.getName());
            System.out.println("email = " + resultVO.getEmail());

            
            return "index";

        }
        
                
        

        
    }

    
}

